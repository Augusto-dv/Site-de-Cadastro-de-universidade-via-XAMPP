<?php

use src\repositorios\repositorioUsuario;

require_once '../repositorios/repositorio_usuario.php';

$repoUsuario = new repositorioUsuario();

$listaUsuarios = $repoUsuario->listarUsuarioCurso($id_curso);

$quantidade = 0;
if ($listaUsuarios) {
    $quantidade = count($listaUsuarios);
} else {
    echo "<h1> Não há alunos no curso selecionado! </h1>";
}