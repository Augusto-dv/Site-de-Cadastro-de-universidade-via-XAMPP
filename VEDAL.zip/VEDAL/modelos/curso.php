<?php

namespace src\modelo;

class Curso{

    private $id;
    private $nome;
	private $valor;
	private $carga_horaria;
    private $categoria;

    public function getId(){
		return $this->id;
	}

	public function setId($id){
		$this->id = $id;
	}

	public function getNome(){
		return $this->nome;
	}

	public function setNome($nome){
		$this->nome = $nome;
	}

	public function getValor(){
		return $this->valor;
	}

	public function setValor($valor){
		$this->valor = $valor;
	}

	public function getCategoria(){
		return $this->categoria;
	}

	public function getCarga_horaria(){
		return $this->carga_horaria;
	}

	public function setCarga_horaria($carga_horaria){
		$this->carga_horaria = $carga_horaria;
	}

	public function setCategoria($categoria){
		$this->categoria = $categoria;
    }
    
    public function __construct()
    {}

}


