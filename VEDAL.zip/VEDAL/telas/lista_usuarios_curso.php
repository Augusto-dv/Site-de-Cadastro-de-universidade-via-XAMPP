<html>
<?php

$id_curso = $_GET['id'];

require_once '../actions/validacao_session.php';
require_once '../actions/listar_usuario_curso_action.php';

$nome_curso = "";
if ($listaUsuarios != null) {
    $nome_curso = $listaUsuarios[0]->getCursoNome();
}


?>

<head>
    <title>Consulta</title>
    <link rel="stylesheet" href="CSS/consulta.css">
</head>

<body>
    <h1>
        <?php echo $nome_curso ?>
        <a id="botao" href="./home.php"></a>
    </h1>

    <br>
    <h3>Alunos:</h3>
    <table id="consultados">
        <tr>
            <th>Nome</th>
            <th>CPF</th>
            <th>E-mail</th>
            <th>Curso</th>
            <th>Matrícula</th>
            <th>Telefone</th>
            <th>Ação</th>
        </tr>
        <?php
        for ($i = 0; $i < $quantidade; $i++) {

            echo "<tr>";

            echo "<th>" . $listaUsuarios[$i]->getNome() . "</th>";
            echo "<th>" . $listaUsuarios[$i]->getCpf() . "</th>";
            echo "<th>" . $listaUsuarios[$i]->getEmail() . "</th>";
            echo "<th>" . $listaUsuarios[$i]->getCursoNome() . "</th>";
            echo "<th>" . $listaUsuarios[$i]->getMatricula() . "</th>";
            echo "<th>" . $listaUsuarios[$i]->getTelefone() . "</th>";
            echo '<th><a href="./tela_dados_usuario.php?id=' . $listaUsuarios[$i]->getId() . '"><i class="fa fa-edit"></i></a> | '
                . '<a href="../actions/deletar_usuario_action.php?id=' . $listaUsuarios[$i]->getId() . '"><i class="fa fa-trash"></i></a></th>';

            echo "</tr>";
        }
        ?>
        <tr>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
        </tr>
    </table>
</body>

</html>