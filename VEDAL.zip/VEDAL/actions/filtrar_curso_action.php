<?php

use src\repositorios\RepositorioCurso;

$nome = $_POST['nome'];
$valor = $_POST['valor'];
$carga_horaria = $_POST['carga_horaria'];
$categoria = $_POST['categoria'];

require_once '../repositorios/repositorio_curso.php';

$repoCurso = new RepositorioCurso();

$listaCursos = $repoCurso->filtrarCurso($nome, $valor, $carga_horaria, $categoria);

$quantidade = 0;

if ($listaCursos) {
    $quantidade = count($listaCursos);
} else {
    echo "<h1> Curso não encontrado! </h1>";
}
