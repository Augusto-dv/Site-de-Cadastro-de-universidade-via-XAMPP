<?php

use src\modelo\Usuario;
use src\repositorios\repositorioUsuario;

require_once '../modelos/usuario.php';
require_once '../repositorios/repositorio_usuario.php';

$controle = $_GET['index'];

if ($controle == "true") {
    $nome = $_POST['NOME'];
    $email = $_POST['EMAIL'];
    $senha = $_POST['SENHA'];
    $cpf = null;
    $nascimento = null;
    $endereco = null;
    $telefone = null;
    $matricula = null;
    $curso_id = null;
    $categoria = null;
} else {
    $nome = $_POST['NOME'];
    $cpf = $_POST['CPF'];
    $nascimento = $_POST['NASCIMENTO'];
    $endereco = $_POST['ENDERECO'];
    $telefone = $_POST['TELEFONE'];
    $matricula = $_POST['MATRICULA'];
    $email = $_POST['EMAIL'];
    $senha = $_POST['SENHA'];
    $curso_id = $_POST['CURSO_ID'];
    $categoria = $_POST['CATEGORIA'];
}

$repoUsuario = new repositorioUsuario();
$usuario = new Usuario();

$usuario->setNome($nome);
$usuario->setCpf($cpf);
$usuario->setDataNascimento($nascimento);
$usuario->setEndereco($endereco);
$usuario->setTelefone($telefone);
$usuario->setMatricula($matricula);
$usuario->setEmail($email);
$usuario->setSenha($senha);
$usuario->setCurso_id($curso_id);
$usuario->setCategoria($categoria);

$resultado = $repoUsuario->cadastrarUsuario($usuario);

if ($resultado) {
    if ($controle == "true") {
        header("location: /VEDAL/actions/login_action.php?controle=true&login=$email&senha=$senha"); 
    } else {
        header("location: /VEDAL/telas/lista_usuario.php?controle_filtro=false");
    }
} else {
    echo "<h1> ERRO! </h1>";
}
