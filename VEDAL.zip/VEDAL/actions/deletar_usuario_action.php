<?php
$id = $_GET['id'];

use src\modelo\Usuario;
use src\repositorios\repositorioUsuario;

require_once '../repositorios/repositorio_usuario.php';
require_once '../modelos/usuario.php';

$repoUsuario = new repositorioUsuario();

$usuario = new Usuario();

$usuario->setId($id);

$status = $repoUsuario->deletarUsuario($usuario);

if ($status) {
    header("location: /VEDAL/telas/lista_usuario.php?controle_filtro=false");
} else {
    echo "<h1> ERRO! </h1>";
}
