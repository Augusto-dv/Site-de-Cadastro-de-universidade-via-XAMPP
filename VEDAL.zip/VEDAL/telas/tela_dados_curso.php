<html>
<?php

use src\modelo\Curso;
use src\repositorios\RepositorioCurso;

require_once '../actions/validacao_session.php';
require_once '../modelos/curso.php';

$id = $_GET['id'];

if ($id != "novo") {

    require_once '../repositorios/repositorio_curso.php';
    $repoCurso = new repositorioCurso();
    $curso_base = $repoCurso->consultarCursoId($id);
    $title = "Alterar Curso";
    $h1 = "Dados Pessoais";

    $controle_alteracao = "/VEDAL/actions/alterar_curso_action.php?id=$id";
} else {

    $title = "Cadastro de Curso";
    $h1 = "Cadastro";

    $curso_base = new Curso();
    $controle_alteracao = "/VEDAL/actions/cadastro_curso_action.php?id=$id";
}

?>

<head>
    <title><?php echo $title; ?></title>

    <link rel="stylesheet" href="CSS/tela_cadastro_usuario.css">
    <meta charset="UTF-8">
</head>

<body>
    <div id="pag">
        <h1><?php echo $h1; ?></h1>
    </div>

    <form action="<?php echo $controle_alteracao; ?>" method="POST">
        <table id="dados">
            <tr>
                <th>NOME</th>
                <th><input id="NOME" name="NOME" value="<?php echo $curso_base->getNome(); ?>"></th>
            </tr>

            <tr>
                <th> VALOR</th>
                <th><input id="VALOR" name="VALOR" type="value" value="<?php echo $curso_base->getValor(); ?>"></th>
            </tr>

            <tr>
                <th>CARGA HORARIA</th>
                <th><input id="CARGA_HORARIA" name="CARGA_HORARIA" value="<?php echo $curso_base->getCarga_horaria(); ?>"></th>
            </tr>

            <tr>
                <th>CATEGORIA</th>
                <th><input id="CATEGORIA" name="CATEGORIA" value="<?php echo $curso_base->getCategoria(); ?>"></th>
            </tr>

            <tr>
                <th><button id="envio_formulario">Cadastrar</button></th>
            </tr>
        </table>
    </form>


</body>

</html>