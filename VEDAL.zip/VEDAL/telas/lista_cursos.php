<html>
<?php
require_once '../actions/validacao_session.php';

$controle = $_GET['controle_filtro'];

if ($controle == "false") {
    require_once '../actions/listar_curso_action.php';
} else {
    require_once '../actions/filtrar_curso_action.php';
}

if ($logado_categoria == "Gestor") {

    $controle_acao = '<th>Ação</th>';
    $controle_acao3 = '<th><a href="./tela_dados_curso.php?id=novo"> <i class="fas fa-plus"></i></a></th> ';
} else {

    $controle_acao = "";
    $controle_acao3 = "";
}

?>

<head>
    <title>Consulta</title>
    <link rel="stylesheet" href="CSS/consulta.css">
</head>

<body>
    <h1>
        Consulta
        <a id="botao" href="./home.php"></a>
    </h1>
    <form action="../telas/lista_cursos.php?controle_filtro=true" method="POST">
        <table id="consulta">
            <tr>
                <th>Nome: <input type="text" name="nome"></th>
                <th>Valor: <input type="text" name="valor"></th>
            </tr>
            <tr>
                <th>Carga Horária: <input type="text" name="carga_horaria"></th>
                <th>Categoria: <input type="text" name="categoria"></th>
            </tr>
        </table>
        <br>
        <button>CONSULTAR</button>
    </form>
    <br>
    <h3>Cursos:</h3>
    <table id="consultados">
        <tr>
            <th>Nome</th>
            <th>Valor</th>
            <th>Carga Horária</th>
            <th>Categoria</th>
            <?php echo $controle_acao; ?>
        </tr>
        <?php
        for ($i = 0; $i < $quantidade; $i++) {

            echo "<tr>";

            if ($logado_categoria == "Gestor") {
                echo '<th><a href="./lista_usuarios_curso.php?id=' . $listaCursos[$i]->getId() . '">' . $listaCursos[$i]->getNome() . "</a></th>";
            } else {
                echo '<th>' . $listaCursos[$i]->getNome() . '</a></th>';
            }

            echo "<th>" . $listaCursos[$i]->getValor() . "</th>";
            echo "<th>" . $listaCursos[$i]->getCarga_horaria() . "</th>";
            echo "<th>" . $listaCursos[$i]->getCategoria() . "</th>";

            if ($logado_categoria == "Gestor") {
                echo '<th><a href="./tela_dados_curso.php?id=' . $listaCursos[$i]->getId() . '"><i class="fa fa-edit"></i></a> | '
                    . ' <a href="../actions/deletar_curso_action.php?id=' . $listaCursos[$i]->getId() . '"><i class="fa fa-trash"></i></a></th>';
            }

            echo "</tr>";
        }
        ?>
        <tr>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <?php echo $controle_acao3 ?>
        </tr>
    </table>
</body>

</html>