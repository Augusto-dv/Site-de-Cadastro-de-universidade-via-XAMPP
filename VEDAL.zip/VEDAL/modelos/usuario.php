<?php

namespace src\modelo;

class Usuario
{

    private $id;
    private $nome;
    private $matricula;
    private $cpf;
    private $telefone;
    private $endereco;
    private $email;
    private $senha;
    private $categoria;
    private $curso_id;
    private $turma_id;
    private $dataNascimento;
    private $cursoNome;

    public function getId()
    {
        return $this->id;
    }

    public function setId($id)
    {
        $this->id = $id;
    }

    public function getNome()
    {
        return $this->nome;
    }

    public function setNome($nome)
    {
        $this->nome = $nome;
    }

    public function getMatricula()
    {
        return $this->matricula;
    }

    public function setMatricula($matricula)
    {
        $this->matricula = $matricula;
    }

    public function getCpf()
    {
        return $this->cpf;
    }

    public function setCpf($cpf)
    {
        $this->cpf = $cpf;
    }

    public function getTelefone()
    {
        return $this->telefone;
    }

    public function setTelefone($telefone)
    {
        $this->telefone = $telefone;
    }

    public function getEndereco()
    {
        return $this->endereco;
    }

    public function setEndereco($endereco)
    {
        $this->endereco = $endereco;
    }

    public function getEmail()
    {
        return $this->email;
    }

    public function setEmail($email)
    {
        $this->email = $email;
    }

    public function getSenha()
    {
        return $this->senha;
    }

    public function setSenha($senha)
    {
        $this->senha = $senha;
    }

    public function getCategoria()
    {
        return $this->categoria;
    }

    public function setCategoria($categoria)
    {
        $this->categoria = $categoria;
    }

    public function getCurso_id()
    {
        return $this->curso_id;
    }

    public function setCurso_id($curso_id)
    {
        $this->curso_id = $curso_id;
    }

    public function getTurma_id()
    {
        return $this->turma_id;
    }

    public function setTurma_id($turma_id)
    {
        $this->turma_id = $turma_id;
    }

    public function getDataNascimento()
    {
        return $this->dataNascimento;
    }

    public function setDataNascimento($dataNascimento)
    {
        $this->dataNascimento = $dataNascimento;
    }

    public function getCursoNome()
    {
        return $this->cursoNome;
    }

    public function setCursoNome($cursoNome)
    {
        $this->cursoNome = $cursoNome;
    }

    public function __construct()
    {
    }
}
