<html>
<?php

use src\modelo\Usuario;
use src\repositorios\repositorioUsuario;

require_once '../actions/validacao_session.php';
require_once '../modelos/usuario.php';
require_once '../modelos/curso.php';
require_once '../actions/listar_curso_action.php';

$id = $_GET['id'];

if ($id != "novo") {

    require_once '../repositorios/repositorio_usuario.php';
    $repoUsuario = new repositorioUsuario();
    $usuario_base = $repoUsuario->consultarUsuarioID($id);
    $title = "Alterar Usuário";
    $h1 = "Dados Pessoais";

    $controle_alteracao = "/VEDAL/actions/alterar_usuario_action.php?id=$id";
} else {

    $title = "Cadastro de Usuário";
    $h1 = "Cadastro";
    $usuario_base = new Usuario();
    $controle_alteracao = "/VEDAL/actions/cadastro_usuario_action.php?index=false";
}
?>

<head>
    <title><?php echo $title; ?></title>

    <link rel="stylesheet" href="CSS/tela_cadastro_usuario.css">
    <meta charset="UTF-8">
</head>

<body>
    <div id="pag">
        <h1><?php echo $h1; ?></h1>
    </div>

    <form action="<?php echo $controle_alteracao; ?>" method="POST">
        <table id="dados">
            <tr>
                <th>NOME</th>
                <th><input id="NOME" name="NOME" value="<?php echo $usuario_base->getNome(); ?>"></th>
            </tr>

            <tr>
                <th>CPF</th>
                <th><input id="CPF" name="CPF" value="<?php echo $usuario_base->getCpf(); ?>"></th>
            </tr>

            <tr>
                <th>DATA DE NASCIMENTO</th>
                <th><input id="NASCIMENTO" name="NASCIMENTO" type="date" value="<?php echo $usuario_base->getDataNascimento(); ?>"></th>
            </tr>

            <tr>
                <th>ENDEREÇO</th>
                <th><input id="ENDERECO" name="ENDERECO" value="<?php echo $usuario_base->getEndereco(); ?>"></th>
            </tr>

            <tr>
                <th>TELEFONE</th>
                <th><input id="TELEFONE" name="TELEFONE" value="<?php echo $usuario_base->getTelefone(); ?>"></th>
            </tr>

            <tr>
                <th>MATRÍCULA</th>
                <th><input id="MATRICULA" name="MATRICULA" value="<?php echo $usuario_base->getMatricula(); ?>"></th>
            </tr>

            <tr>
                <th>E-MAIL</th>
                <th><input id="EMAIL" name="EMAIL" type="email" value="<?php echo $usuario_base->getEmail(); ?>"></th>
            </tr>

            <tr>
                <th>SENHA</th>
                <th><input id="SENHA" name="SENHA" type="password"></th>
            </tr>

            <tr>
                <th>CURSO</th>
                <th>
                    <select name="CURSO_ID" id="CURSO_ID">
                        <option></option>
                        <?php
                        for ($i = 0; $i < $quantidade; $i++) {

                            $id_curso_usuario = $usuario_base->getCurso_id();
                            $id_curso_geral = $listaCursos[$i]->getId();
                            $nomeCurso = $listaCursos[$i]->getNome();
                        ?>

                            <option value="<?php echo $id_curso_geral ?>" <?php if ($id_curso_usuario == $id_curso_geral) {
                                                                                echo "selected";
                                                                            } ?>><?php echo $nomeCurso; ?></option>

                        <?php } ?>
                    </select>
                </th>
            </tr>

            <?php if ($logado_categoria == "Gestor") { ?>

                <tr>
                    <th>CATEGORIA</th>
                    <th>
                        <select name="CATEGORIA" id="CATEGORIA">
                            <option value=""></option>
                            <option value="Aluno" <?php if ($_SESSION['CATEGORIA'] == "Aluno") {
                                                        echo "selected";
                                                    } ?>>Aluno</option>
                            <option value="Gestor" <?php if ($_SESSION['CATEGORIA'] == "Gestor") {
                                                        echo "selected";
                                                    } ?>>Gestor</option>
                        </select>
                    </th>
                </tr>
            <?php } ?>

            <tr>
                <th><button id="envio_formulario">Cadastrar</button></th>
            </tr>
        </table>
    </form>


</body>

</html>