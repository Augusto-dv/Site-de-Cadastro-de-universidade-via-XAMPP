<?php

namespace src\repositorios;

use mysqli;
use src\ConexaoMySQL;
use src\modelo\Usuario;

require_once '../src/conexao_mysql.php';
require_once '../modelos/usuario.php';

class repositorioUsuario
{
    private $usuario;
    private $conexao;

    public function __construct()
    {
        $this->conexao = new ConexaoMySQL();
        $this->usuario = new Usuario();
    }

    public function listarUsuario()
    {
        $listaUsuarios = null;

        $query = "SELECT TB_USUARIO.*, TB_CURSO.NOME AS CURSO_NOME FROM TB_USUARIO LEFT OUTER JOIN TB_CURSO ON TB_USUARIO.CURSO_ID=TB_CURSO.ID;";

        $conexao = $this->conexao->abrirBanco();

        $resultado = $conexao->query($query);

        if ($resultado->num_rows > 0) {

            for ($i = 0; $linha = $resultado->fetch_assoc(); $i++) {

                $usuario = new Usuario();

                $usuario->setId($linha['ID']);
                $usuario->setNome($linha['NOME']);
                $usuario->setMatricula($linha['MATRICULA']);
                $usuario->setCpf($linha['CPF']);
                $usuario->setTelefone($linha['TELEFONE']);
                $usuario->setEndereco($linha['ENDERECO']);
                $usuario->setEmail($linha['EMAIL']);
                $usuario->setSenha($linha['SENHA']);
                $usuario->setCategoria($linha['CATEGORIA']);
                $usuario->setCurso_id($linha['CURSO_ID']);
                $usuario->setDataNascimento($linha['DATA_NASCIMENTO']);
                $usuario->setCursoNome($linha['CURSO_NOME']);

                $listaUsuarios[$i] = $usuario;
            }
        } else {
            $listaUsuarios = false;
        }

        $conexao = $this->conexao->fecharBanco();

        return $listaUsuarios;
    }

    public function consultarUsuarioID($id)
    {
        $usuario = null;

        $query = "SELECT * FROM PROJETO.TB_USUARIO WHERE ID = $id;";

        $conexao = $this->conexao->abrirBanco();

        $resultado = $conexao->query($query);

        if ($resultado != null) {

            $linha = $resultado->fetch_assoc();

            $usuario = new Usuario();

            $usuario->setId($linha['ID']);
            $usuario->setNome($linha['NOME']);
            $usuario->setMatricula($linha['MATRICULA']);
            $usuario->setCpf($linha['CPF']);
            $usuario->setTelefone($linha['TELEFONE']);
            $usuario->setEndereco($linha['ENDERECO']);
            $usuario->setEmail($linha['EMAIL']);
            $usuario->setSenha($linha['SENHA']);
            $usuario->setCategoria($linha['CATEGORIA']);
            $usuario->setCurso_id($linha['CURSO_ID']);
            $usuario->setDataNascimento($linha['DATA_NASCIMENTO']);
        } else {
            $usuario = false;
        }

        $conexao = $this->conexao->fecharBanco();

        return $usuario;
    }

    public function cadastrarUsuario($usuario)
    {
        $status = false;

        $nome = $usuario->getNome();
        $matricula = $usuario->getMatricula();
        $cpf = $usuario->getCpf();
        $telefone = $usuario->getTelefone();
        $endereco = $usuario->getEndereco();
        $email = $usuario->getEmail();
        $senha = $usuario->getSenha();
        $categoria = $usuario->getCategoria();
        $curso_id = $usuario->getCurso_id();
        $data_nascimento = $usuario->getDataNascimento();

        if (!isset($matricula)) {
            $query = "INSERT INTO TB_USUARIO(NOME,EMAIL,SENHA) VALUES ('" .
                $nome . "', '"
                . $email . "', '"
                . $senha . "');";
        } else {
            $query = "INSERT INTO TB_USUARIO(NOME,MATRICULA,CPF,TELEFONE,ENDERECO,EMAIL,SENHA,CATEGORIA,CURSO_ID,DATA_NASCIMENTO) VALUES ('" .
                $nome . "', '"
                . $matricula . "', '"
                . $cpf . "', '"
                . $telefone . "', '"
                . $endereco . "', '"
                . $email . "', '"
                . $senha . "', '"
                . $categoria . "', '"
                . $curso_id . "', '"
                . $data_nascimento . "');";
        }
        $conexao = $this->conexao->abrirBanco();

        if ($conexao->query($query)) {
            $status = true;
        } else {
            echo mysqli_error($conexao);
        }

        $conexao = $this->conexao->fecharBanco();

        return $status;
    }


    public function login($email, $senha)
    {

        $usuario = null;

        $query = "SELECT ID, CATEGORIA, CURSO_ID FROM PROJETO.TB_USUARIO WHERE EMAIL = '$email' AND SENHA = '$senha'";

        $conexao = $this->conexao->abrirBanco();


        $resultado = $conexao->query($query);

        if ($resultado != null) {

            $linha = $resultado->fetch_assoc();

            $usuario = new Usuario();

            $usuario->setId($linha['ID']);
            $usuario->setCategoria($linha['CATEGORIA']);
            $usuario->setCurso_id($linha['CURSO_ID']);
        } else {
            $usuario = false;
        }

        $conexao = $this->conexao->fecharBanco();

        return $usuario;
    }


    public function filtrarUsuario($nome, $cpf, $email, $matricula)
    {
        $listaUsuarios = null;

        if ($nome != "") {
            $nome = "TB_USUARIO.NOME LIKE '%$nome%'";
        } else {
            $nome = "1=1";
        }

        if ($cpf != "") {
            $cpf = "CPF LIKE '%$cpf%'";
        } else {
            $cpf = "2=2";
        }

        if ($email != "") {
            $email = "EMAIL LIKE '%$email%'";
        } else {
            $email = "3=3";
        }

        if ($matricula != "") {
            $matricula = "MATRICULA LIKE '%$matricula%'";
        } else {
            $matricula = "4=4";
        }

        $query = "SELECT TB_USUARIO.*, TB_CURSO.NOME AS CURSO_NOME FROM TB_USUARIO LEFT OUTER JOIN TB_CURSO ON TB_USUARIO.CURSO_ID=TB_CURSO.ID WHERE $nome AND $cpf AND $email AND $matricula;";

        $conexao = $this->conexao->abrirBanco();

        $resultado = $conexao->query($query);

        if ($resultado != null) {

            for ($i = 0; $linha = $resultado->fetch_assoc(); $i++) {

                $usuario = new Usuario();

                $usuario->setId($linha['ID']);
                $usuario->setNome($linha['NOME']);
                $usuario->setMatricula($linha['MATRICULA']);
                $usuario->setCpf($linha['CPF']);
                $usuario->setTelefone($linha['TELEFONE']);
                $usuario->setEndereco($linha['ENDERECO']);
                $usuario->setEmail($linha['EMAIL']);
                $usuario->setSenha($linha['SENHA']);
                $usuario->setCategoria($linha['CATEGORIA']);
                $usuario->setCurso_id($linha['CURSO_ID']);
                $usuario->setDataNascimento($linha['DATA_NASCIMENTO']);
                $usuario->setCursoNome($linha['CURSO_NOME']);

                $listaUsuarios[$i] = $usuario;
            }
        } else {
            $listaUsuarios = false;
        }

        $conexao = $this->conexao->fecharBanco();

        return $listaUsuarios;
    }

    public function AlterarUsuario($usuario)
    {
        $status = false;

        $id = $usuario->getId();
        $nome = $usuario->getNome();
        $matricula = $usuario->getMatricula();
        $cpf = $usuario->getCpf();
        $telefone = $usuario->getTelefone();
        $endereco = $usuario->getEndereco();
        $email = $usuario->getEmail();
        $senha = $usuario->getSenha();
        $categoria = $usuario->getCategoria();
        $curso_id = $usuario->getCurso_id();
        $data_nascimento = $usuario->getDataNascimento();

        if ($senha == "") {
            $query = " UPDATE PROJETO.TB_USUARIO SET 
            NOME = '$nome',
            MATRICULA = '$matricula',
            CPF = '$cpf',
            TELEFONE = '$telefone',
            ENDERECO = '$telefone',
            EMAIL = '$email',
            CATEGORIA = '$categoria',
            CURSO_ID = $curso_id,
            DATA_NASCIMENTO = '$data_nascimento'
            WHERE ID = $id;";
        } else {
            $query = " UPDATE PROJETO.TB_USUARIO SET 
            NOME = '$nome',
            MATRICULA = '$matricula',
            CPF = '$cpf',
            TELEFONE = '$telefone',
            ENDERECO = '$telefone',
            EMAIL = '$email',
            SENHA = '$senha',
            CATEGORIA = '$categoria',
            CURSO_ID = $curso_id,
            DATA_NASCIMENTO = '$data_nascimento'
            WHERE ID = $id;";
        }

        $conexao = $this->conexao->abrirBanco();

        if ($conexao->query($query)) {
            $status = true;
        } else {
            echo mysqli_error($conexao);
        }

        $conexao = $this->conexao->fecharBanco();

        return $status;
    }

    public function deletarUsuario($usuario)
    {
        $status = false;

        $id = $usuario->getId();

        $query = " DELETE FROM PROJETO.TB_USUARIO WHERE ID = $id";

        $conexao = $this->conexao->abrirBanco();

        if ($conexao->query($query)) {
            $status = true;
        } else {
            echo mysqli_error($conexao);
        }

        $conexao = $this->conexao->fecharBanco();

        return $status;
    }

    public function listarUsuarioCurso($id)
    {
        $listaUsuarios = null;

        $query = "SELECT TB_USUARIO.*, TB_CURSO.NOME AS CURSO_NOME FROM TB_USUARIO LEFT OUTER JOIN TB_CURSO ON TB_USUARIO.CURSO_ID=TB_CURSO.ID WHERE CURSO_ID = $id;";

        $conexao = $this->conexao->abrirBanco();

        $resultado = $conexao->query($query);

        if ($resultado->num_rows > 0) {

            for ($i = 0; $linha = $resultado->fetch_assoc(); $i++) {

                $usuario = new Usuario();

                $usuario->setId($linha['ID']);
                $usuario->setNome($linha['NOME']);
                $usuario->setMatricula($linha['MATRICULA']);
                $usuario->setCpf($linha['CPF']);
                $usuario->setTelefone($linha['TELEFONE']);
                $usuario->setEndereco($linha['ENDERECO']);
                $usuario->setEmail($linha['EMAIL']);
                $usuario->setSenha($linha['SENHA']);
                $usuario->setCategoria($linha['CATEGORIA']);
                $usuario->setCurso_id($linha['CURSO_ID']);
                $usuario->setDataNascimento($linha['DATA_NASCIMENTO']);
                $usuario->setCursoNome($linha['CURSO_NOME']);

                $listaUsuarios[$i] = $usuario;
            }
        } else {
            $listaUsuarios = false;
        }

        $conexao = $this->conexao->fecharBanco();

        return $listaUsuarios;
    }
}
