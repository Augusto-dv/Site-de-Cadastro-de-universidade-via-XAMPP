<?php

use src\modelo\Curso;
use src\repositorios\RepositorioCurso;

$id = $_GET['id'];
$nome = $_POST['NOME'];
$valor = $_POST['VALOR'];
$carga_horaria = $_POST['CARGA_HORARIA'];
$categoria = $_POST['CATEGORIA'];

require_once '../modelos/curso.php';
require_once '../repositorios/repositorio_curso.php';

$repoCurso = new RepositorioCurso();
$curso = new Curso();

$curso->setNome($nome);
$curso->setValor($valor);
$curso->setCarga_horaria($carga_horaria);
$curso->setCategoria($categoria);

$resultado = $repoCurso->cadastrarCurso($curso);

if ($resultado) {
    header("location: /VEDAL/telas/lista_cursos.php?controle_filtro=false");
} else {
    echo "<h1> ERRO! </h1>";
}
