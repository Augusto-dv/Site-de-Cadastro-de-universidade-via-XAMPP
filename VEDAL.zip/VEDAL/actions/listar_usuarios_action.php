<?php

use src\repositorios\repositorioUsuario;

require_once '../repositorios/repositorio_usuario.php';

$repoUsuario = new repositorioUsuario();

$listaUsuarios = $repoUsuario->listarUsuario();

$quantidade = 0;
if ($listaUsuarios) {
    $quantidade = count($listaUsuarios);
} else {
    echo "<h1> ERRO! </h1>";
}

