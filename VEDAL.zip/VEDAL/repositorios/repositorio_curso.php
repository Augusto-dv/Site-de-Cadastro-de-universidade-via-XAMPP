<?php

namespace src\repositorios;

use mysqli;
use src\ConexaoMySQL;
use src\modelo\Curso;

require_once '../src/conexao_mysql.php';
require_once '../modelos/curso.php';

class RepositorioCurso
{
    private $curso;
    private $Conexao;

    public function __construct()
    {
        $this->Conexao = new ConexaoMySQL();
        $this->Curso = new Curso();
    }

    public function listarCursos()
    {
        $listaCursos = null;

        $query = "SELECT * FROM PROJETO.TB_CURSO;";

        $conexao = $this->Conexao->abrirBanco();

        $resultado = $conexao->query($query);

        if ($resultado->num_rows > 0) {

            for ($i = 0; $linha = $resultado->fetch_assoc(); $i++) {

                $curso = new Curso();

                $curso->setId($linha['ID']);
                $curso->setNome($linha['NOME']);
                $curso->setValor($linha['VALOR']);
                $curso->setCarga_horaria($linha['CARGA_HORARIA']);
                $curso->setCategoria($linha['CATEGORIA']);

                $listaCursos[$i] = $curso;
            }
        } else {
            $listaCursos = false;
        }

        return $listaCursos;
    }

    public function consultarCursoId($id)
    {
        $curso = null;
        $query = "SELECT * FROM PROJETO.TB_CURSO WHERE ID = $id";
        $conexao = $this->Conexao->abrirBanco();
        $resultado = $conexao->query($query);

        if ($resultado->num_rows != null) {

            for ($i = 0; $linha = $resultado->fetch_assoc(); $i++) {

                $curso = new Curso();

                $curso->setId($linha['ID']);
                $curso->setNome($linha['NOME']);
                $curso->setValor($linha['VALOR']);
                $curso->setCarga_horaria($linha['CARGA_HORARIA']);
                $curso->setCategoria($linha['CATEGORIA']);
            }
        } else {
            $curso = false;
        }

        $this->Conexao->fecharBanco();

        return $curso;
    }

    public function cadastrarCurso($curso)
    {
        $status = false;

        $nome = $curso->getNome();
        $valor = $curso->getValor();
        $carga_horaria = $curso->getCarga_horaria();
        $categoria = $curso->getCategoria();

        $query = "INSERT INTO PROJETO.TB_CURSO (NOME,VALOR,CARGA_HORARIA,CATEGORIA) VALUES ('$nome',$valor,$carga_horaria,'$categoria');";

        $conexao = $this->Conexao->abrirBanco();

        if ($conexao->query($query)) {
            $status = true;
        } else {
            echo mysqli_error($conexao);
        }

        $conexao = $this->Conexao->abrirBanco();

        return $status;
    }

    public function filtrarCurso($nome, $valor, $carga_horaria, $categoria)
    {
        $listaCursos = null;

        if ($nome != "") {
            $nome = "NOME LIKE '%$nome%'";
        } else {
            $nome = "1=1";
        }

        if ($valor != "") {
            $valor = "VALOR LIKE '%$valor%'";
        } else {
            $valor = "2=2";
        }

        if ($carga_horaria != "") {
            $carga_horaria = "CARGA_HORARIA LIKE '%$carga_horaria%'";
        } else {
            $carga_horaria = "3=3";
        }

        if ($categoria != "") {
            $categoria = "CATEGORIA LIKE '%$categoria%'";
        } else {
            $categoria = "4=4";
        }

        $query = "SELECT * FROM PROJETO.TB_CURSO WHERE $nome AND $valor AND $carga_horaria AND $categoria;";

        $conexao = $this->Conexao->abrirBanco();

        $resultado = $conexao->query($query);

        if ($resultado != null) {

            for ($i = 0; $linha = $resultado->fetch_assoc(); $i++) {

                $curso = new Curso();

                $curso->setId($linha['ID']);
                $curso->setNome($linha['NOME']);
                $curso->setValor($linha['VALOR']);
                $curso->setCarga_horaria($linha['CARGA_HORARIA']);
                $curso->setCategoria($linha['CATEGORIA']);

                $listaCursos[$i] = $curso;
            }
        } else {
            $listaCursos = false;
        }

        $conexao = $this->Conexao->abrirBanco();

        return $listaCursos;
    }

    public function alterarCurso($curso)
    {
        $status = false;

        $id = $curso->getId();
        $nome = $curso->getNome();
        $valor = $curso->getValor();
        $carga_horaria = $curso->getCarga_horaria();
        $categoria = $curso->getCategoria();

        $query = "UPDATE PROJETO.TB_CURSO SET NOME = '$nome',VALOR = $valor,CARGA_HORARIA = $carga_horaria,CATEGORIA = '$categoria' WHERE ID = $id ";

        $conexao = $this->Conexao->abrirBanco();

        if ($conexao->query($query)) {
            $status = true;
        } else {
            echo mysqli_error($conexao);
        }

        $conexao = $this->Conexao->fecharBanco();

        return $status;
    }

    public function deletarCurso($curso)
    {
        $status = false;

        $id = $curso->getId();

        $query = " DELETE FROM PROJETO.TB_CURSO WHERE ID = $id";

        $conexao = $this->Conexao->abrirBanco();

        if ($conexao->query($query)) {
            $status = true;
        } else {
            echo mysqli_error($conexao);
        }

        $conexao = $this->Conexao->fecharBanco();

        return $status;
    }
}
