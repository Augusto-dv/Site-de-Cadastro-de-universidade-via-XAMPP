<html>
<?php
require_once '../actions/validacao_session.php';

if ($logado_categoria == "Aluno") {
    header("location: /VEDAL/telas/home.php");
}

$controle = $_GET['controle_filtro'];

if ($controle == "false") {
    require_once '../actions/listar_usuarios_action.php';
} else {
    require_once '../actions/filtrar_usuarios_action.php';
}

?>

<head>
    <title>Consulta</title>
    <link rel="stylesheet" href="CSS/consulta.css">
</head>

<body>
    <h1>
        Consulta
        <a id="botao" href="./home.php"></a>
    </h1>
    <form action="../telas/lista_usuario.php?controle_filtro=true" method="POST">
        <table id="consulta">
            <tr>
                <th>Nome: <input type="text" name="nome"></th>
                <th>CPF: <input type="text" name="cpf"></th>
            </tr>
            <tr>
                <th>E-mail: <input type="text" name="email"></th>
                <th>Matrícula: <input type="text" name="matricula"></th>
            </tr>
        </table>
        <br>
        <button>CONSULTAR</button>
    </form>
    <br>
    <h3>Usuários:</h3>
    <table id="consultados">
        <tr>
            <th>Nome</th>
            <th>CPF</th>
            <th>E-mail</th>
            <th>Curso</th>
            <th>Matrícula</th>
            <th>Telefone</th>
            <th>Ação</th>
        </tr>
        <?php
        for ($i = 0; $i < $quantidade; $i++) {

            echo "<tr>";

            echo "<th>" . $listaUsuarios[$i]->getNome() . "</th>";
            echo "<th>" . $listaUsuarios[$i]->getCpf() . "</th>";
            echo "<th>" . $listaUsuarios[$i]->getEmail() . "</th>";
            echo "<th>" . $listaUsuarios[$i]->getCursoNome() . "</th>";
            echo "<th>" . $listaUsuarios[$i]->getMatricula() . "</th>";
            echo "<th>" . $listaUsuarios[$i]->getTelefone() . "</th>";
            echo '<th><a href="./tela_dados_usuario.php?id=' . $listaUsuarios[$i]->getId() . '"><i class="fa fa-edit"></i></a> | '
                . '<a href="../actions/deletar_usuario_action.php?id=' . $listaUsuarios[$i]->getId() . '"><i class="fa fa-trash"></i></a></th>';

            echo "</tr>";
        }
        ?>
        <tr>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th><a href="./tela_dados_usuario.php?id=novo"> <i class="fas fa-user-plus"></i></a> </th>
        </tr>
    </table>
</body>

</html>