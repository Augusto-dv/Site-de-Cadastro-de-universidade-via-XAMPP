<?php

$id = $_GET['id'];

use src\modelo\Curso;
use src\repositorios\RepositorioCurso;

require_once '../modelos/curso.php';
require_once '../repositorios/repositorio_curso.php';

$repoCurso = new RepositorioCurso();
$curso = new Curso();

$curso->setId($id);

$status = $repoCurso->deletarCurso($curso);

if ($status) {
    header("location: /VEDAL/telas/lista_cursos.php?controle_filtro=false");
} else {
    echo "<h1> ERRO! </h1>";
}
