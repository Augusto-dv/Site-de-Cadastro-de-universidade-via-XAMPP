<?php

$id = $_GET['id'];
$nome = $_POST['NOME'];
$cpf = $_POST['CPF'];
$nascimento = $_POST['NASCIMENTO'];
$endereco = $_POST['ENDERECO'];
$telefone = $_POST['TELEFONE'];
$matricula = $_POST['MATRICULA'];
$email = $_POST['EMAIL'];
$senha = $_POST['SENHA'];
$curso_id = $_POST['CURSO_ID'];
$categoria = $_POST['CATEGORIA'];

use src\modelo\Usuario;
use src\repositorios\repositorioUsuario;

require_once '../modelos/usuario.php';
require_once '../repositorios/repositorio_usuario.php';

$repoUsuario = new repositorioUsuario();
$usuario = new Usuario();

$usuario->setId($id);
$usuario->setNome($nome);
$usuario->setCpf($cpf);
$usuario->setDataNascimento($nascimento);
$usuario->setEndereco($endereco);
$usuario->setTelefone($telefone);
$usuario->setMatricula($matricula);
$usuario->setEmail($email);
$usuario->setSenha($senha);
$usuario->setCurso_id($curso_id);
$usuario->setCategoria($categoria);

$status = $repoUsuario->AlterarUsuario($usuario);

if ($status) {
    header("location: /VEDAL/telas/lista_usuario.php?controle_filtro=false");
} else {
    echo "<h1> ERRO! </h1>";
}
