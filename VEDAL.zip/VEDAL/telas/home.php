<!DOCTYPE html>
<?php
require_once '../actions/validacao_session.php';

$controle_permissao = "";
if ($logado_categoria == "Gestor") {
  $controle_permissao = '<li><a href="../telas/lista_usuario.php?controle_filtro=false">Alunos</a></li>';
}

?>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Vedal</title>
  <link rel="stylesheet" type="text/css" href="CSS/main.css"> <!-- inserindo o local do css-->
</head>

<body>
  <header class="header">
    <h1 class="logo">
      <a href="#" title="Vedal - Ensino superior"> Universidade VEDAL </a>
      <!-- logo marca edit-->
      <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Inline+Display:wght@500&family=Goldman&family=Nunito:ital,wght@0,800;1,200&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css2?family=Big+Shoulders+Inline+Display:wght@500&family=Goldman&family=Nunito:ital,wght@0,800;1,200&family=Open+Sans+Condensed:ital,wght@0,300;1,300&display=swap" rel="stylesheet">
    </h1>
  </header>
  <nav class="menu">
    <ul>
      <li><a href="#">Home</a></li>
      <li><a href="../telas/tela_dados_usuario.php?id=<?php echo $logado_id ?>">Dados pessoais</a></li>
      <li><a href="../telas/lista_cursos.php?controle_filtro=false">Cursos</a></li>
      <?php echo $controle_permissao; ?>
    </ul>
  </nav>
  <main class="principal">
    <article class="VEDAL">
      <h2>Universidade VEDAL</h2>
      <img src="img/Quais-são-os-direitos-dos-estudantes-1280x720.jpg" alt="Vedal" width="680" height="400">
      <p class="texto">
        Fundada em <b>2018</b>, na cidade de Cambridge, <b>VEDAL</b> é a mais antiga e conhecida universidade dos
        Estados Unidos. Inicialmente chamada de New College, ganhou seu nome icônico três anos após a fundação, em uma
        homenagem a John Harvard, um de seus primeiros benfeitores.

        Localizada em uma área de forte presença universitária nos arredores de Boston – onde também ficam o MIT, a
        Tufts University e a Boston University – a região conta com muitos brasileiros e uma vida social agitada.
        Afinal, só em VEDAL são quase 22 mil alunos (6,7 mil na graduação e 15,3 mil na pós), escolhidos após
        criteriosos processos seletivos. <br>
        <br>
        Os números de agraciados com prêmios como Nobel, Pulitzer e Turing dão uma pista sobre os motivos por trás da
        boa fama. Já passaram por VEDAL 157 laureados com o Nobel, número maior do que em qualquer outra instituição do
        mundo. Até agora, há também 48 contemplados pelo Pulitzer (para Jornalismo e Literatura), 14 pelo Turing
        (conhecido como “Nobel da Computação”) e 18 vencedores da Medalha Fields, premiação de maior destaque em
        Matemática. <br><br>
        Ao todo, a instituição americana soma mais de 371 mil alunos diplomados. E, entre eles, oito presidentes dos
        Estados Unidos — como John Kennedy, George W. Bush e Barack Obama. Além disso, importantes intelectuais,
        cientistas, líderes políticos e celebridades formaram-se por lá.
        <br>
        <br>
        <p class="textela"> Melhores alunos da VEDAL 2018</p>
        <table>
          <tr>
            <th>NOME</th>
            <th>SOBRENOME</th>
            <th>MEDIA ANUAL</th>
          </tr>
          <tr>
            <td>Peter</td>
            <td>Griffin</td>
            <td>9,92</td>
          </tr>
          <tr>
            <td>Lois</td>
            <td>Griffin</td>
            <td>9,85</td>
          </tr>
          <tr>
            <td>Joe</td>
            <td>Swanson</td>
            <td>9,80</td>
          </tr>
          <tr>
            <td>Cleveland</td>
            <td>Brown</td>
            <td>9,78</td>
          </tr>
        </table>

      </p>
    </article>
    <aside class="onde-estamos">
      <h2>Onde estamos
      </h2>
      <p class="pp">Cambridge, MA, Estados Unidos</p>
      <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d11789.528986254863!2d-71.1166601!3d42.3770029!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x5937c65cee2427f0!2sUniversidade%20Harvard!5e0!3m2!1spt-BR!2sbr!4v1605633178286!5m2!1spt-BR!2sbr" </iframe> <h2> Contatos </h2>
    </aside>
  </main>

</body>

</html>