<?php

use src\repositorios\RepositorioCurso;

require_once '../repositorios/repositorio_curso.php';

$repoCurso = new RepositorioCurso();

$listaCursos = $repoCurso->listarCursos();

$quantidade = 0;

if ($listaCursos) {
    $quantidade = count($listaCursos);
} else {
    echo "<h1> ERRO! </h1>";
}
