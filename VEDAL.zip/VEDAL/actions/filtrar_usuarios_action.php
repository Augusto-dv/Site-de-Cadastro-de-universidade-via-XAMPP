<?php

use src\repositorios\repositorioUsuario;

$nome = $_POST['nome'];
$cpf = $_POST['cpf'];
$email = $_POST['email'];
$matricula = $_POST['matricula'];

require_once '../repositorios/repositorio_usuario.php';

$repoUsuario = new repositorioUsuario();

$listaUsuarios = $repoUsuario->filtrarUsuario($nome,$cpf,$email,$matricula);

$quantidade = 0;

if ($listaUsuarios) {
    $quantidade = count($listaUsuarios);
} else {
    echo "<h1> Usuário não encontrado! </h1>";
}
