<?php

session_cache_expire(10);
session_start();

if (!isset($_SESSION['ID']) and !isset($_SESSION['CATEGORIA'])) {

    unset($_SESSION['ID']);
    unset($_SESSION['CATEGORIA']);
    unset($_SESSION['CURSO_ID']);
    header('location: ../index.html');
}

$logado_id = $_SESSION['ID'];
$logado_categoria = $_SESSION['CATEGORIA'];
$logado_curso_id = $_SESSION['CURSO_ID'];

echo '<script src="https://kit.fontawesome.com/7d08a7c219.js" crossorigin="anonymous"></script>';