<?php

use src\repositorios\repositorioUsuario;

$controle = $_GET['controle'];

if ($controle == "true") {
    $login = $_GET['login'];
    $senha = $_GET['senha'];
} else {
    $login = $_POST['login'];
    $senha = $_POST['senha'];
}

require_once '../repositorios/repositorio_usuario.php';
$repoUsuario = new repositorioUsuario;

$usuarioLogado = $repoUsuario->login($login, $senha);

if ($usuarioLogado->getId() != null) {
    session_start();
    $_SESSION['ID'] = $usuarioLogado->getId();
    $_SESSION['CATEGORIA'] = $usuarioLogado->getCategoria();
    $_SESSION['CURSO_ID'] = $usuarioLogado->getCurso_id();
    header("location: ../telas/home.php");
} else {
    unset($_SESSION['ID']);
    unset($_SESSION['CATEGORIA']);
    unset($_SESSION['CURSO_ID']);
    header("location: /VEDAL/index.html");
    die();
}
